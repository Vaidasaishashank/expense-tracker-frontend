const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(express.json({ limit: "100kb" }));

// Starter in-memory store: data resets whenever the server restarts.
// For a production app, replace this with a database such as PostgreSQL or MongoDB.
let transactions = [];
let budgets = {};

function validTransaction(body) {
  return body && typeof body.description === "string" && body.description.trim().length > 0
    && ["income", "expense"].includes(body.type)
    && Number.isFinite(Number(body.amount)) && Number(body.amount) > 0
    && typeof body.category === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date);
}

app.get("/", (_req, res) => res.json({
  name: "Expense Tracker & Budget Planner API",
  status: "running",
  endpoints: ["GET /api/health", "GET /api/transactions", "POST /api/transactions",
    "PUT /api/transactions/:id", "DELETE /api/transactions/:id", "GET /api/budgets/:month",
    "PUT /api/budgets/:month"]
}));
app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/transactions", (req, res) => {
  const month = req.query.month;
  res.json(month ? transactions.filter(t => t.date.slice(0, 7) === month) : transactions);
});
app.post("/api/transactions", (req, res) => {
  if (!validTransaction(req.body)) return res.status(400).json({ error: "Provide description, type, positive amount, category and date (YYYY-MM-DD)." });
  const item = { id: String(Date.now()) + Math.random().toString(36).slice(2, 7),
    description: req.body.description.trim(), type: req.body.type, amount: Number(req.body.amount),
    category: req.body.category, date: req.body.date, notes: String(req.body.notes || "").slice(0, 160),
    createdAt: Date.now() };
  transactions.push(item);
  res.status(201).json(item);
});
app.put("/api/transactions/:id", (req, res) => {
  if (!validTransaction(req.body)) return res.status(400).json({ error: "Invalid transaction fields." });
  const index = transactions.findIndex(t => t.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: "Transaction not found." });
  transactions[index] = { ...transactions[index], description: req.body.description.trim(),
    type: req.body.type, amount: Number(req.body.amount), category: req.body.category,
    date: req.body.date, notes: String(req.body.notes || "").slice(0, 160) };
  res.json(transactions[index]);
});
app.delete("/api/transactions/:id", (req, res) => {
  const before = transactions.length;
  transactions = transactions.filter(t => t.id !== req.params.id);
  if (transactions.length === before) return res.status(404).json({ error: "Transaction not found." });
  res.status(204).end();
});
app.get("/api/budgets/:month", (req, res) => {
  if (!/^\d{4}-\d{2}$/.test(req.params.month)) return res.status(400).json({ error: "Month must be YYYY-MM." });
  res.json({ month: req.params.month, amount: budgets[req.params.month] || 0 });
});
app.put("/api/budgets/:month", (req, res) => {
  if (!/^\d{4}-\d{2}$/.test(req.params.month)) return res.status(400).json({ error: "Month must be YYYY-MM." });
  const amount = Number(req.body.amount);
  if (!Number.isFinite(amount) || amount < 0) return res.status(400).json({ error: "Budget must be a non-negative number." });
  budgets[req.params.month] = amount;
  res.json({ month: req.params.month, amount });
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});
app.listen(PORT, () => console.log(`Expense Tracker API listening on port ${PORT}`));
