# SpendWise API — Backend

A small REST API using Node.js and Express for the Expense Tracker & Budget Planner project.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Visit `http://localhost:3000/api/health` and expect `{"status":"ok"}`.

## Endpoints
- `GET /api/health` — health check
- `GET /api/transactions?month=YYYY-MM` — list transactions
- `POST /api/transactions` — create transaction
- `PUT /api/transactions/:id` — update transaction
- `DELETE /api/transactions/:id` — delete transaction
- `GET /api/budgets/YYYY-MM` — get budget
- `PUT /api/budgets/YYYY-MM` — set budget

Example JSON for `POST /api/transactions`:
```json
{
  "description": "Groceries",
  "type": "expense",
  "amount": 450,
  "category": "Food",
  "date": "2026-10-13",
  "notes": "Weekly shopping"
}
```

## Deployment
Create a GitHub repository named `expense-tracker-backend` and upload the contents of this folder to its root. Create a Web Service on Render from that repository. Use build command `npm install` and start command `npm start`. Render provides the actual service URL after deployment.

## Important limitations
This is an educational starter API. It stores data in memory, so records reset when the service restarts, and it has no user login or database. Do not use it for sensitive financial data. The frontend currently uses browser localStorage and is not yet wired to this API.
