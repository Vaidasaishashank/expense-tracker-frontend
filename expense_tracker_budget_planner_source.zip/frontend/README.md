# SpendWise — Expense Tracker & Budget Planner (Frontend)

A responsive personal-finance dashboard built with HTML, CSS and vanilla JavaScript.

## Features
- Add, edit and delete income/expense transactions
- Categories, dates, notes, search and type filters
- Monthly income, expenses and available-balance summary
- Monthly budget and spending progress
- Export the selected month's transactions to CSV
- Persists data in the browser with `localStorage`

## Run locally
Open `index.html` in a browser. For a local web server, run `python -m http.server 5500` from this folder, then open `http://localhost:5500`.

## Deploy
1. Create a GitHub repository named `expense-tracker-frontend`.
2. Upload the contents of this folder to the repository root.
3. Import that repository into Vercel or enable GitHub Pages.
4. Copy the actual deployed URL into your college form.

## Important limitation
This frontend stores data in the current browser only. It does not sync records between devices or users. The companion backend is a separate starter API. Connecting the UI to that API is a possible extension.
