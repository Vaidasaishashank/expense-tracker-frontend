const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "spendwise_transactions_v1";
const BUDGET_KEY = "spendwise_budgets_v1";
let transactions = readJSON(STORAGE_KEY, []);
let budgets = readJSON(BUDGET_KEY, {});
let selectedMonth = new Date().toISOString().slice(0, 7);

function readJSON(key, fallback) {
  try { const value = JSON.parse(localStorage.getItem(key)); return value ?? fallback; }
  catch { return fallback; }
}
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  localStorage.setItem(BUDGET_KEY, JSON.stringify(budgets));
}
function money(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(value || 0);
}
function monthTransactions() {
  return transactions.filter(t => t.date && t.date.slice(0, 7) === selectedMonth);
}
function resetForm() {
  $("transactionForm").reset();
  $("transactionId").value = "";
  $("date").value = new Date().toISOString().slice(0, 10);
  $("formHeading").textContent = "Add a transaction";
  $("saveButton").textContent = "Add transaction";
  $("cancelEdit").classList.add("hidden");
}
function render() {
  const monthItems = monthTransactions();
  const income = monthItems.filter(t => t.type === "income").reduce((sum, t) => sum + t.amount, 0);
  const expenses = monthItems.filter(t => t.type === "expense").reduce((sum, t) => sum + t.amount, 0);
  const budget = Number(budgets[selectedMonth] || 0);
  $("incomeTotal").textContent = money(income);
  $("expenseTotal").textContent = money(expenses);
  $("balanceTotal").textContent = money(income - expenses);
  $("budgetTotal").textContent = money(budget);
  $("spentSoFar").textContent = money(expenses);
  $("budgetRemaining").textContent = money(budget - expenses);
  $("budgetRemaining").classList.toggle("negative-budget", budget > 0 && expenses > budget);
  $("budgetNote").textContent = budget ? `${Math.round(expenses / budget * 100)}% of budget used` : "Set a budget to get started";
  $("budgetBar").style.width = `${budget ? Math.min(100, expenses / budget * 100) : 0}%`;
  $("budgetBar").style.background = budget && expenses > budget ? "var(--red)" : "var(--green)";
  $("budgetInput").value = budgets[selectedMonth] ?? "";
  const query = $("searchInput").value.trim().toLowerCase();
  const type = $("typeFilter").value;
  const filtered = [...transactions].filter(t => t.date.slice(0,7) === selectedMonth)
    .filter(t => type === "all" || t.type === type)
    .filter(t => `${t.description} ${t.category} ${t.notes || ""}`.toLowerCase().includes(query))
    .sort((a,b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt);
  $("transactionRows").innerHTML = filtered.map(t => `
    <tr>
      <td>${escapeHTML(t.description)}${t.notes ? `<span class="subnote">${escapeHTML(t.notes)}</span>` : ""}</td>
      <td><span class="category-pill">${escapeHTML(t.category)}</span></td>
      <td>${formatDate(t.date)}</td>
      <td><span class="type-pill ${t.type}">${t.type === "income" ? "Income" : "Expense"}</span></td>
      <td class="right amount-cell ${t.type === "income" ? "positive" : "negative"}">${t.type === "income" ? "+" : "−"}${money(t.amount)}</td>
      <td><div class="actions"><button class="mini-button" data-edit="${t.id}">Edit</button><button class="mini-button delete" data-delete="${t.id}">Delete</button></div></td>
    </tr>`).join("");
  $("emptyState").classList.toggle("hidden", filtered.length > 0);
  $("recordCount").textContent = `${filtered.length} record${filtered.length === 1 ? "" : "s"}`;
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function formatDate(value) {
  const date = new Date(`${value}T00:00:00`);
  return date.toLocaleDateString("en-IN", {day:"2-digit", month:"short", year:"numeric"});
}
$("monthFilter").value = selectedMonth;
$("date").value = new Date().toISOString().slice(0, 10);
$("monthFilter").addEventListener("change", e => { selectedMonth = e.target.value || new Date().toISOString().slice(0,7); render(); });
$("searchInput").addEventListener("input", render);
$("typeFilter").addEventListener("change", render);
$("transactionForm").addEventListener("submit", e => {
  e.preventDefault();
  const description = $("description").value.trim();
  const amount = Number($("amount").value);
  const date = $("date").value;
  if (!description || !Number.isFinite(amount) || amount <= 0 || !date) {
    $("formMessage").textContent = "Enter a description, a valid amount, and a date.";
    return;
  }
  const id = $("transactionId").value;
  const old = transactions.find(t => t.id === id);
  const item = { id: id || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())), description,
    type: $("type").value, amount, category: $("category").value, date,
    notes: $("notes").value.trim(), createdAt: old?.createdAt || Date.now() };
  if (id) transactions = transactions.map(t => t.id === id ? item : t);
  else transactions.push(item);
  saveData(); resetForm(); $("formMessage").textContent = id ? "Transaction updated." : "Transaction added."; render();
});
$("cancelEdit").addEventListener("click", () => { resetForm(); $("formMessage").textContent = ""; });
$("transactionRows").addEventListener("click", e => {
  const editId = e.target.dataset.edit;
  const deleteId = e.target.dataset.delete;
  if (editId) {
    const t = transactions.find(item => item.id === editId);
    if (!t) return;
    $("transactionId").value = t.id; $("description").value = t.description; $("type").value = t.type;
    $("amount").value = t.amount; $("category").value = t.category; $("date").value = t.date; $("notes").value = t.notes || "";
    $("formHeading").textContent = "Edit transaction"; $("saveButton").textContent = "Save changes";
    $("cancelEdit").classList.remove("hidden"); $("formMessage").textContent = ""; window.scrollTo({top:0,behavior:"smooth"});
  }
  if (deleteId) {
    const t = transactions.find(item => item.id === deleteId);
    if (t && confirm(`Delete "${t.description}"?`)) { transactions = transactions.filter(item => item.id !== deleteId); saveData(); render(); }
  }
});
$("budgetForm").addEventListener("submit", e => {
  e.preventDefault();
  const amount = Number($("budgetInput").value);
  if (!Number.isFinite(amount) || amount < 0) return;
  budgets[selectedMonth] = amount; saveData(); render();
});
$("exportButton").addEventListener("click", () => {
  const rows = [["Description","Type","Amount (INR)","Category","Date","Notes"]];
  monthTransactions().forEach(t => rows.push([t.description,t.type,t.amount,t.category,t.date,t.notes || ""]));
  const csv = rows.map(row => row.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob); const a = document.createElement("a");
  a.href = url; a.download = `spendwise-${selectedMonth}.csv`; a.click(); URL.revokeObjectURL(url);
});
render();
